package DataAccessLayer;

public class T_dwVO{
private int dw_id;
private String dw_nam;
private String dw_zzh;
private String dw_frdb;
private int dw_frzjh;
private String dw_ywfw;
private String dw_zczj;
private String dw_xzid;
private String dw_hyid;

public T_dwVO()
{//TODO ������������ݵ�
	}
public int getDw_id()
{
	return dw_id;}
public String getDw_nam()
{
	return dw_nam;}
public String getDw_zzh()
{
	return dw_zzh;}
public String getDw_frdb()
{
	return dw_frdb;}
public int getDw_frzjh()
{
	return dw_frzjh;}
public String getDw_ywfw()
{
	return dw_ywfw;}
public String getDw_zczj()
{
	return dw_zczj;}
public String getDw_xzid()
{
	return dw_xzid;}
public String getDw_hyid()
{
	return dw_hyid;}



public void setDw_id(int dw_id)
{
	this.dw_id=dw_id;}
public void setDw_nam(String dw_nam)
{
	this.dw_nam=dw_nam;}
public void setDw_zzh(String dw_zzh)
{
	this.dw_zzh=dw_zzh;}
public void setDw_frdb(String dw_frdb)
{
	this.dw_frdb=dw_frdb;}
public void setDw_frzjh(int dw_frzjh)
{
	this.dw_frzjh=dw_frzjh;}
public void setDw_ywfw(String dw_ywfw)
{
	this.dw_ywfw=dw_ywfw;}
public void setDw_zczj(String dw_zczj)
{
	this.dw_zczj=dw_zczj;}
public void setDw_xzid(String dw_xzid)
{
	this.dw_xzid=dw_xzid;}
public void setDw_hyid(String dw_hyid)
{
	this.dw_hyid=dw_hyid;}
}