package DataAccessLayer;


public interface Dk_khDAO
{
	public boolean updateDk_kh(Dk_khVO dk_khVO);
	public boolean insertDk_kh(Dk_khVO dk_khVO);
	public boolean deleteDk_kh(Dk_khVO dk_khVO);
}
