package DataAccessLayer;

public interface T_dkfhDAO {
	public boolean updateT_dkfh(T_dkfhVO t_dkfhVO);
	public boolean insertT_dkfh(T_dkfhVO t_dkfhVO);
	public boolean deleteT_dkfh(T_dkfhVO t_dkfhVO);
}
