package DataAccessLayer;
import java.util.*;

public class T_dkfhVO{
private String dkbh;
private int khid;
private int dksqid;
private String kmh;
private String sybz;
private String dkbz;
private String dkksrq;
private String kddqrq;
//©����������ֱ�Ӻ��ӣ���Ҫ��
private String dkzqrq;
private String zhhkrq;
private String zhjxrq;
private float ye; //��������Ѹ�
private float sjll;
private float zqll;
private float yqll;
private float fqll;

public T_dkfhVO()
{//TODO ������������ݵ�
	}
public String getDkbh()
{
	return dkbh;}
public int getKhid()
{
	return khid;}
public int getDksqid()
{
	return dksqid;}
public String getKmh()
{
	return kmh;}
public String getSybz()
{
	return sybz;}
public String getDkbz()
{
	return dkbz;}
public String getDkksrq()
{
	return dkksrq;}
public String getKddqrq()
{
	return kddqrq;}
public String getDkzqrq()
{
	return dkzqrq;}
public String getZhhkrq()
{
	return zhhkrq;}
public String getZhjxrq()
{
	return zhjxrq;}
public float getYe()
{
	return ye;}
public float getSjll()
{
	return sjll;}
public float getZqll()
{
	return zqll;}
public float getYqll()
{
	return yqll;}
public float getFqll()
{
	return fqll;}


public void setDkbh(String dkbh)
{
	this.dkbh=dkbh;}
public void setKhid(int khid)
{
	this.khid=khid;}
public void setDksqid(int dksqid)
{
	this.dksqid=dksqid;}
public void setKmh(String kmh)
{
	this.kmh=kmh;}
public void setSybz(String sybz)
{
	this.sybz=sybz;}
public void setDkbz(String dkbz)
{
	this.dkbz=dkbz;}
public void setDkksrq(String dkksrq)
{
	this.dkksrq=dkksrq;}


public void setKddqrq(String kddqrq)
{
	this.kddqrq=kddqrq;}
public void setDkzqrq(String dkzqrq)
{
	this.dkzqrq=dkzqrq;}
public void setZhhkrq(String zhhkrq)
{
	this.zhhkrq=zhhkrq;}
public void setZhjxrq(String zhjxrq)
{
	this.zhjxrq=zhjxrq;}
public void setYe(float ye)
{
	this.ye=ye;}
public void setSjll(float sjll)
{
	this.sjll=sjll;}
public void setZqll(float zqll)
{
	this.zqll=zqll;}
public void setYqll(float yqll)
{
	this.yqll=yqll;}
public void setFqll(float fqll)
{
	this.fqll=fqll;}
}