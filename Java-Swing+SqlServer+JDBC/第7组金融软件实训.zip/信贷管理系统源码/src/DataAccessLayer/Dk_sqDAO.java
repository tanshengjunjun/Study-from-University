package DataAccessLayer;

public interface Dk_sqDAO {
public boolean updateDk_sq(Dk_sqVO dk_sqVO);
public boolean insertDk_sq(Dk_sqVO dk_sqVO);
public boolean deleteDk_sq(Dk_sqVO dk_sqVO);
}
