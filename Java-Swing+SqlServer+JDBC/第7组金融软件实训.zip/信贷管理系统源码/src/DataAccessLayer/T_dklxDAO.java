package DataAccessLayer;

public interface T_dklxDAO {
	public boolean updateT_dklx(T_dklxVO t_dklxVO);
	public boolean insertT_dklx(T_dklxVO t_dklxVO);
	public boolean deleteT_dklx(T_dklxVO t_dklxVO);
}
